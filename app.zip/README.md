# reto-tecnico-backend-interseguroNode
Esta API recibirá los datos de la matriz rotada de la API en Go
